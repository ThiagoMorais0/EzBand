--
-- PostgreSQL database dump
--

\restrict IcCWT07hdaGbNJuzDDHzLQc15tOveRe4SW9uiXR39Zkymg47YbAZIsFsgGBUN6s

-- Dumped from database version 17.6 (Debian 17.6-1.pgdg13+1)
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: avaliacao_estudio; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.avaliacao_estudio (
    id bigint NOT NULL,
    atendimento integer NOT NULL,
    data_avaliacao date,
    estrutura integer NOT NULL,
    experiencia_geral integer NOT NULL,
    organizacao integer NOT NULL,
    qualidade_som integer NOT NULL,
    id_estudio bigint,
    id_usuario bigint
);


ALTER TABLE public.avaliacao_estudio OWNER TO "user";

--
-- Name: avaliacao_estudio_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.avaliacao_estudio_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.avaliacao_estudio_id_seq OWNER TO "user";

--
-- Name: avaliacao_estudio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.avaliacao_estudio_id_seq OWNED BY public.avaliacao_estudio.id;


--
-- Name: avaliacao_local_evento; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.avaliacao_local_evento (
    id bigint NOT NULL,
    atendimento integer NOT NULL,
    data_avaliacao date,
    estrutura integer NOT NULL,
    experiencia_geral integer NOT NULL,
    organizacao integer NOT NULL,
    qualidade_som integer NOT NULL,
    id_local_evento bigint,
    id_usuario bigint
);


ALTER TABLE public.avaliacao_local_evento OWNER TO "user";

--
-- Name: avaliacao_local_evento_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.avaliacao_local_evento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.avaliacao_local_evento_id_seq OWNER TO "user";

--
-- Name: avaliacao_local_evento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.avaliacao_local_evento_id_seq OWNED BY public.avaliacao_local_evento.id;


--
-- Name: banda; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.banda (
    id bigint NOT NULL,
    categoria character varying(255),
    data_inclusao date,
    descricao character varying(255),
    bairro character varying(255),
    cep character varying(255),
    cidade character varying(255),
    estado character varying(255),
    numero character varying(255),
    pais character varying(255),
    rua character varying(255),
    nome character varying(255),
    exigir_aprovacao_compromissos boolean,
    listar_observacao_repertorio boolean,
    permite_entrada_por_convite boolean,
    url_logo character varying(1000)
);


ALTER TABLE public.banda OWNER TO "user";

--
-- Name: banda_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.banda_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.banda_id_seq OWNER TO "user";

--
-- Name: banda_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.banda_id_seq OWNED BY public.banda.id;


--
-- Name: condicao_orcamento; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.condicao_orcamento (
    id bigint NOT NULL,
    condicao character varying(255),
    id_banda bigint,
    id_orcamento bigint
);


ALTER TABLE public.condicao_orcamento OWNER TO "user";

--
-- Name: condicao_orcamento_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.condicao_orcamento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.condicao_orcamento_id_seq OWNER TO "user";

--
-- Name: condicao_orcamento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.condicao_orcamento_id_seq OWNED BY public.condicao_orcamento.id;


--
-- Name: ensaio; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.ensaio (
    id bigint NOT NULL,
    data date,
    data_inclusao date,
    duracao time(6) without time zone,
    bairro character varying(255),
    cep character varying(255),
    cidade character varying(255),
    estado character varying(255),
    numero character varying(255),
    pais character varying(255),
    rua character varying(255),
    horario_inicio time(6) without time zone,
    local character varying(255),
    observacoes character varying(255),
    status character varying(255),
    tipo_evento character varying(255),
    valor numeric(38,2),
    id_banda bigint,
    id_estudio bigint,
    CONSTRAINT ensaio_status_check CHECK (((status)::text = ANY ((ARRAY['PENDENTE'::character varying, 'REALIZADO'::character varying, 'CANCELADO'::character varying, 'AGUARDANDO_APROVACAO'::character varying, 'AGUARDANDO_APROVACAO_ORCAMENTO'::character varying])::text[]))),
    CONSTRAINT ensaio_tipo_evento_check CHECK (((tipo_evento)::text = ANY ((ARRAY['SHOW'::character varying, 'ENSAIO'::character varying])::text[])))
);


ALTER TABLE public.ensaio OWNER TO "user";

--
-- Name: ensaio_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.ensaio_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ensaio_id_seq OWNER TO "user";

--
-- Name: ensaio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.ensaio_id_seq OWNED BY public.ensaio.id;


--
-- Name: equipamento_estudio; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.equipamento_estudio (
    id bigint NOT NULL,
    ativo boolean,
    marca character varying(255),
    modelo character varying(255),
    observacao character varying(255),
    quantidade integer,
    id_estudio bigint
);


ALTER TABLE public.equipamento_estudio OWNER TO "user";

--
-- Name: equipamento_estudio_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.equipamento_estudio_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.equipamento_estudio_id_seq OWNER TO "user";

--
-- Name: equipamento_estudio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.equipamento_estudio_id_seq OWNED BY public.equipamento_estudio.id;


--
-- Name: equipamento_local_evento; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.equipamento_local_evento (
    id bigint NOT NULL,
    ativo boolean,
    marca character varying(255),
    modelo character varying(255),
    observacao character varying(255),
    quantidade integer,
    id_local_evento bigint
);


ALTER TABLE public.equipamento_local_evento OWNER TO "user";

--
-- Name: equipamento_local_evento_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.equipamento_local_evento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.equipamento_local_evento_id_seq OWNER TO "user";

--
-- Name: equipamento_local_evento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.equipamento_local_evento_id_seq OWNED BY public.equipamento_local_evento.id;


--
-- Name: estado_notificacao; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.estado_notificacao (
    id bigint NOT NULL,
    mensagem_adicional character varying(500),
    status_notificacao character varying(255),
    id_usuario bigint,
    id_notificacao bigint,
    CONSTRAINT estado_notificacao_status_notificacao_check CHECK (((status_notificacao)::text = ANY ((ARRAY['NAO_VISUALIZADO'::character varying, 'VISUALIZADO'::character varying, 'ACEITO'::character varying, 'RECUSADO'::character varying])::text[])))
);


ALTER TABLE public.estado_notificacao OWNER TO "user";

--
-- Name: estado_notificacao_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.estado_notificacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.estado_notificacao_id_seq OWNER TO "user";

--
-- Name: estado_notificacao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.estado_notificacao_id_seq OWNED BY public.estado_notificacao.id;


--
-- Name: estudio; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.estudio (
    id bigint NOT NULL,
    data_inclusao timestamp(6) without time zone,
    descricao character varying(255),
    bairro character varying(255),
    cep character varying(255),
    cidade character varying(255),
    estado character varying(255),
    numero character varying(255),
    pais character varying(255),
    rua character varying(255),
    horario_final_funcionamento timestamp(6) without time zone,
    horario_inicio_funcionamento timestamp(6) without time zone,
    nome character varying(255),
    url_foto_perfil character varying(255),
    id_usuario bigint
);


ALTER TABLE public.estudio OWNER TO "user";

--
-- Name: estudio_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.estudio_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.estudio_id_seq OWNER TO "user";

--
-- Name: estudio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.estudio_id_seq OWNED BY public.estudio.id;


--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.flyway_schema_history OWNER TO "user";

--
-- Name: item_orcamento; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.item_orcamento (
    id bigint NOT NULL,
    nome_parametro character varying(255),
    quantidade numeric(38,2),
    subtotal numeric(38,2),
    unidade character varying(255),
    valor_customizado numeric(38,2),
    valor_unitario numeric(38,2),
    id_orcamento bigint
);


ALTER TABLE public.item_orcamento OWNER TO "user";

--
-- Name: item_orcamento_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.item_orcamento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.item_orcamento_id_seq OWNER TO "user";

--
-- Name: item_orcamento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.item_orcamento_id_seq OWNED BY public.item_orcamento.id;


--
-- Name: local_evento; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.local_evento (
    id bigint NOT NULL,
    data_inclusao timestamp(6) without time zone,
    bio character varying(255),
    bairro character varying(255),
    cep character varying(255),
    cidade character varying(255),
    estado character varying(255),
    numero character varying(255),
    pais character varying(255),
    rua character varying(255),
    horario_final_funcionamento timestamp(6) without time zone,
    horario_inicio_funcionamento timestamp(6) without time zone,
    nome character varying(255),
    url_foto_perfil character varying(255),
    id_usuario bigint
);


ALTER TABLE public.local_evento OWNER TO "user";

--
-- Name: local_evento_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.local_evento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.local_evento_id_seq OWNER TO "user";

--
-- Name: local_evento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.local_evento_id_seq OWNED BY public.local_evento.id;


--
-- Name: musico_banda; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.musico_banda (
    instrumentos character varying(255),
    id_banda bigint NOT NULL,
    id_usuario bigint NOT NULL
);


ALTER TABLE public.musico_banda OWNER TO "user";

--
-- Name: musico_evento; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.musico_evento (
    id_evento bigint NOT NULL,
    id_usuario bigint NOT NULL,
    tipo_evento character varying(255) NOT NULL,
    cache numeric(38,2),
    instrumentos character varying(255),
    situacao character varying(255),
    CONSTRAINT musico_evento_situacao_check CHECK (((situacao)::text = ANY ((ARRAY['ATIVO'::character varying, 'CONVITE_PENDENTE'::character varying, 'INATIVO'::character varying])::text[]))),
    CONSTRAINT musico_evento_tipo_evento_check CHECK (((tipo_evento)::text = ANY ((ARRAY['SHOW'::character varying, 'ENSAIO'::character varying])::text[])))
);


ALTER TABLE public.musico_evento OWNER TO "user";

--
-- Name: notificacao; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.notificacao (
    tipo character varying(100) NOT NULL,
    id bigint NOT NULL,
    data_criacao timestamp(6) without time zone,
    destinatario_id bigint,
    destinatario_tipo character varying(255),
    lida boolean NOT NULL,
    mensagem character varying(255),
    remetente_id bigint,
    remetente_tipo character varying(255),
    titulo character varying(255),
    url_imagem character varying(1000),
    id_ensaio bigint,
    tipo_evento smallint,
    CONSTRAINT notificacao_destinatario_tipo_check CHECK (((destinatario_tipo)::text = ANY ((ARRAY['USUARIO'::character varying, 'BANDA'::character varying, 'ESTUDIO'::character varying, 'LOCAL_EVENTOno'::character varying])::text[]))),
    CONSTRAINT notificacao_remetente_tipo_check CHECK (((remetente_tipo)::text = ANY ((ARRAY['USUARIO'::character varying, 'BANDA'::character varying, 'ESTUDIO'::character varying, 'LOCAL_EVENTOno'::character varying])::text[]))),
    CONSTRAINT notificacao_tipo_evento_check CHECK (((tipo_evento >= 0) AND (tipo_evento <= 1)))
);


ALTER TABLE public.notificacao OWNER TO "user";

--
-- Name: notificacao_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.notificacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notificacao_id_seq OWNER TO "user";

--
-- Name: notificacao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.notificacao_id_seq OWNED BY public.notificacao.id;


--
-- Name: orcamento; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.orcamento (
    id bigint NOT NULL,
    data_geracao timestamp(6) without time zone,
    valor_total numeric(38,2),
    id_banda bigint,
    id_evento bigint
);


ALTER TABLE public.orcamento OWNER TO "user";

--
-- Name: orcamento_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.orcamento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orcamento_id_seq OWNER TO "user";

--
-- Name: orcamento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.orcamento_id_seq OWNED BY public.orcamento.id;


--
-- Name: parametro_custo; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.parametro_custo (
    id bigint NOT NULL,
    descricao character varying(255),
    nome character varying(255),
    tipo_calculo character varying(255),
    unidade character varying(255),
    valor_unitario numeric(38,2),
    id_banda bigint,
    CONSTRAINT parametro_custo_tipo_calculo_check CHECK (((tipo_calculo)::text = ANY ((ARRAY['POR_MUSICO'::character varying, 'POR_DIA'::character varying, 'POR_KM'::character varying, 'VALOR_FIXO'::character varying])::text[])))
);


ALTER TABLE public.parametro_custo OWNER TO "user";

--
-- Name: parametro_custo_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.parametro_custo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.parametro_custo_id_seq OWNER TO "user";

--
-- Name: parametro_custo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.parametro_custo_id_seq OWNED BY public.parametro_custo.id;


--
-- Name: permissao_musico_banda; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.permissao_musico_banda (
    id_banda bigint NOT NULL,
    id_usuario bigint NOT NULL,
    permissoes character varying(255),
    CONSTRAINT permissao_musico_banda_permissoes_check CHECK (((permissoes)::text = ANY ((ARRAY['MEMBRO_REGULAR'::character varying, 'GERENCIADOR_DE_ENSAIOS'::character varying, 'GERENCIADOR_DE_SHOWS'::character varying, 'ADMINISTRADOR'::character varying, 'GERENCIA_ORCAMENTOS'::character varying, 'FUNDADOR'::character varying])::text[])))
);


ALTER TABLE public.permissao_musico_banda OWNER TO "user";

--
-- Name: relacionamento_seguidor; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.relacionamento_seguidor (
    id_seguido bigint NOT NULL,
    id_seguidor bigint NOT NULL,
    data_aceitacao date,
    data_solicitacao date,
    status smallint,
    CONSTRAINT relacionamento_seguidor_status_check CHECK (((status >= 0) AND (status <= 2)))
);


ALTER TABLE public.relacionamento_seguidor OWNER TO "user";

--
-- Name: repertorio_banda; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.repertorio_banda (
    id bigint NOT NULL,
    artista character varying(255),
    descricao character varying(255),
    duracao time(6) without time zone,
    observacao character varying(255),
    titulo character varying(255),
    tonalidade character varying(255),
    id_banda bigint,
    CONSTRAINT repertorio_banda_tonalidade_check CHECK (((tonalidade)::text = ANY ((ARRAY['ORIGINAL'::character varying, 'MEIO_TOM_ABAIXO'::character varying, 'UM_TOM_ABAIXO'::character varying, 'UM_TOM_E_MEIO_ABAIXO'::character varying, 'DOIS_TONS_ABAIXO'::character varying, 'DOIS_TONS_E_MEIO_ABAIXO'::character varying, 'TRES_TONS_ABAIXO'::character varying, 'TRES_TONS_E_MEIO_ABAIXO'::character varying, 'QUATRO_TONS_ABAIXO'::character varying, 'QUATRO_TONS_E_MEIO_ABAIXO'::character varying, 'CINCO_TONS_ABAIXO'::character varying, 'CINCO_TONS_E_MEIO_ABAIXO'::character varying, 'SEIS_TONS_ABAIXO'::character varying, 'SEIS_TONS_E_MEIO_ABAIXO'::character varying, 'SETE_TONS_ABAIXO'::character varying, 'SETE_TONS_E_MEIO_ABAIXO'::character varying, 'OITO_TONS_ABAIXO'::character varying, 'MEIO_TOM_ACIMA'::character varying, 'UM_TOM_ACIMA'::character varying, 'UM_TOM_E_MEIO_ACIMA'::character varying, 'DOIS_TONS_ACIMA'::character varying, 'DOIS_TONS_E_MEIO_ACIMA'::character varying, 'TRES_TONS_ACIMA'::character varying, 'TRES_TONS_E_MEIO_ACIMA'::character varying, 'QUATRO_TONS_ACIMA'::character varying, 'QUATRO_TONS_E_MEIO_ACIMA'::character varying, 'CINCO_TONS_ACIMA'::character varying, 'CINCO_TONS_E_MEIO_ACIMA'::character varying, 'SEIS_TONS_ACIMA'::character varying, 'SEIS_TONS_E_MEIO_ACIMA'::character varying, 'SETE_TONS_ACIMA'::character varying, 'SETE_TONS_E_MEIO_ACIMA'::character varying, 'OITO_TONS_ACIMA'::character varying, 'OITO_TONS_E_MEIO_ACIMA'::character varying])::text[])))
);


ALTER TABLE public.repertorio_banda OWNER TO "user";

--
-- Name: repertorio_banda_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.repertorio_banda_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.repertorio_banda_id_seq OWNER TO "user";

--
-- Name: repertorio_banda_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.repertorio_banda_id_seq OWNED BY public.repertorio_banda.id;


--
-- Name: repertorio_evento; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.repertorio_evento (
    id_banda bigint NOT NULL,
    id_evento bigint NOT NULL,
    indice integer NOT NULL,
    tipo_evento character varying(255) NOT NULL,
    bloco character varying(255),
    artista character varying(255),
    descricao character varying(255),
    duracao time(6) without time zone,
    observacao character varying(255),
    titulo character varying(255),
    tonalidade character varying(255),
    CONSTRAINT repertorio_evento_tipo_evento_check CHECK (((tipo_evento)::text = ANY ((ARRAY['SHOW'::character varying, 'ENSAIO'::character varying])::text[]))),
    CONSTRAINT repertorio_evento_tonalidade_check CHECK (((tonalidade)::text = ANY ((ARRAY['ORIGINAL'::character varying, 'MEIO_TOM_ABAIXO'::character varying, 'UM_TOM_ABAIXO'::character varying, 'UM_TOM_E_MEIO_ABAIXO'::character varying, 'DOIS_TONS_ABAIXO'::character varying, 'DOIS_TONS_E_MEIO_ABAIXO'::character varying, 'TRES_TONS_ABAIXO'::character varying, 'TRES_TONS_E_MEIO_ABAIXO'::character varying, 'QUATRO_TONS_ABAIXO'::character varying, 'QUATRO_TONS_E_MEIO_ABAIXO'::character varying, 'CINCO_TONS_ABAIXO'::character varying, 'CINCO_TONS_E_MEIO_ABAIXO'::character varying, 'SEIS_TONS_ABAIXO'::character varying, 'SEIS_TONS_E_MEIO_ABAIXO'::character varying, 'SETE_TONS_ABAIXO'::character varying, 'SETE_TONS_E_MEIO_ABAIXO'::character varying, 'OITO_TONS_ABAIXO'::character varying, 'MEIO_TOM_ACIMA'::character varying, 'UM_TOM_ACIMA'::character varying, 'UM_TOM_E_MEIO_ACIMA'::character varying, 'DOIS_TONS_ACIMA'::character varying, 'DOIS_TONS_E_MEIO_ACIMA'::character varying, 'TRES_TONS_ACIMA'::character varying, 'TRES_TONS_E_MEIO_ACIMA'::character varying, 'QUATRO_TONS_ACIMA'::character varying, 'QUATRO_TONS_E_MEIO_ACIMA'::character varying, 'CINCO_TONS_ACIMA'::character varying, 'CINCO_TONS_E_MEIO_ACIMA'::character varying, 'SEIS_TONS_ACIMA'::character varying, 'SEIS_TONS_E_MEIO_ACIMA'::character varying, 'SETE_TONS_ACIMA'::character varying, 'SETE_TONS_E_MEIO_ACIMA'::character varying, 'OITO_TONS_ACIMA'::character varying, 'OITO_TONS_E_MEIO_ACIMA'::character varying])::text[])))
);


ALTER TABLE public.repertorio_evento OWNER TO "user";

--
-- Name: reporte_de_erro; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.reporte_de_erro (
    id bigint NOT NULL,
    mensagem character varying(255),
    id_usuario bigint
);


ALTER TABLE public.reporte_de_erro OWNER TO "user";

--
-- Name: reporte_de_erro_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.reporte_de_erro_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reporte_de_erro_id_seq OWNER TO "user";

--
-- Name: reporte_de_erro_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.reporte_de_erro_id_seq OWNED BY public.reporte_de_erro.id;


--
-- Name: resposta_notificacao; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.resposta_notificacao (
    id bigint NOT NULL,
    acao character varying(255),
    data_resposta timestamp(6) without time zone,
    mensagem character varying(255),
    notificacao_id bigint,
    CONSTRAINT resposta_notificacao_acao_check CHECK (((acao)::text = ANY ((ARRAY['ACEITAR'::character varying, 'RECUSAR'::character varying])::text[])))
);


ALTER TABLE public.resposta_notificacao OWNER TO "user";

--
-- Name: resposta_notificacao_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.resposta_notificacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.resposta_notificacao_id_seq OWNER TO "user";

--
-- Name: resposta_notificacao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.resposta_notificacao_id_seq OWNED BY public.resposta_notificacao.id;


--
-- Name: servico_estudio; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.servico_estudio (
    id bigint NOT NULL,
    descricao character varying(255),
    nome character varying(255),
    valor numeric(38,2),
    id_estudio bigint
);


ALTER TABLE public.servico_estudio OWNER TO "user";

--
-- Name: servico_estudio_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.servico_estudio_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.servico_estudio_id_seq OWNER TO "user";

--
-- Name: servico_estudio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.servico_estudio_id_seq OWNED BY public.servico_estudio.id;


--
-- Name: show; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.show (
    id bigint NOT NULL,
    data date,
    data_inclusao date,
    duracao time(6) without time zone,
    bairro character varying(255),
    cep character varying(255),
    cidade character varying(255),
    estado character varying(255),
    numero character varying(255),
    pais character varying(255),
    rua character varying(255),
    horario_inicio time(6) without time zone,
    local character varying(255),
    observacoes character varying(255),
    status character varying(255),
    tipo_evento character varying(255),
    horario_passagem_som time(6) without time zone,
    is_portaria boolean,
    porcentagem_portaria integer,
    valor_contrato numeric(38,2),
    id_banda bigint,
    id_local_evento bigint,
    CONSTRAINT show_status_check CHECK (((status)::text = ANY ((ARRAY['PENDENTE'::character varying, 'REALIZADO'::character varying, 'CANCELADO'::character varying, 'AGUARDANDO_APROVACAO'::character varying, 'AGUARDANDO_APROVACAO_ORCAMENTO'::character varying])::text[]))),
    CONSTRAINT show_tipo_evento_check CHECK (((tipo_evento)::text = ANY ((ARRAY['SHOW'::character varying, 'ENSAIO'::character varying])::text[])))
);


ALTER TABLE public.show OWNER TO "user";

--
-- Name: show_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.show_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.show_id_seq OWNER TO "user";

--
-- Name: show_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.show_id_seq OWNED BY public.show.id;


--
-- Name: spring_session; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.spring_session (
    primary_id character(36) NOT NULL,
    session_id character(36) NOT NULL,
    creation_time bigint NOT NULL,
    last_access_time bigint NOT NULL,
    max_inactive_interval integer NOT NULL,
    expiry_time bigint NOT NULL,
    principal_name character varying(100)
);


ALTER TABLE public.spring_session OWNER TO "user";

--
-- Name: spring_session_attributes; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.spring_session_attributes (
    session_primary_id character(36) NOT NULL,
    attribute_name character varying(200) NOT NULL,
    attribute_bytes bytea NOT NULL
);


ALTER TABLE public.spring_session_attributes OWNER TO "user";

--
-- Name: usuario; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.usuario (
    id bigint NOT NULL,
    ativo boolean,
    bloqueado boolean,
    celular character varying(255),
    cidade character varying(255),
    data_criacao date,
    data_nascimento date,
    descricao character varying(255),
    email character varying(255),
    nome character varying(255),
    permissao character varying(255),
    senha character varying(255),
    url_foto_perfil character varying(255),
    CONSTRAINT usuario_permissao_check CHECK (((permissao)::text = ANY ((ARRAY['ADMIN'::character varying, 'USUARIO'::character varying])::text[])))
);


ALTER TABLE public.usuario OWNER TO "user";

--
-- Name: usuario_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.usuario_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usuario_id_seq OWNER TO "user";

--
-- Name: usuario_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.usuario_id_seq OWNED BY public.usuario.id;


--
-- Name: avaliacao_estudio id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.avaliacao_estudio ALTER COLUMN id SET DEFAULT nextval('public.avaliacao_estudio_id_seq'::regclass);


--
-- Name: avaliacao_local_evento id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.avaliacao_local_evento ALTER COLUMN id SET DEFAULT nextval('public.avaliacao_local_evento_id_seq'::regclass);


--
-- Name: banda id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.banda ALTER COLUMN id SET DEFAULT nextval('public.banda_id_seq'::regclass);


--
-- Name: condicao_orcamento id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.condicao_orcamento ALTER COLUMN id SET DEFAULT nextval('public.condicao_orcamento_id_seq'::regclass);


--
-- Name: ensaio id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.ensaio ALTER COLUMN id SET DEFAULT nextval('public.ensaio_id_seq'::regclass);


--
-- Name: equipamento_estudio id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.equipamento_estudio ALTER COLUMN id SET DEFAULT nextval('public.equipamento_estudio_id_seq'::regclass);


--
-- Name: equipamento_local_evento id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.equipamento_local_evento ALTER COLUMN id SET DEFAULT nextval('public.equipamento_local_evento_id_seq'::regclass);


--
-- Name: estado_notificacao id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.estado_notificacao ALTER COLUMN id SET DEFAULT nextval('public.estado_notificacao_id_seq'::regclass);


--
-- Name: estudio id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.estudio ALTER COLUMN id SET DEFAULT nextval('public.estudio_id_seq'::regclass);


--
-- Name: item_orcamento id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.item_orcamento ALTER COLUMN id SET DEFAULT nextval('public.item_orcamento_id_seq'::regclass);


--
-- Name: local_evento id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.local_evento ALTER COLUMN id SET DEFAULT nextval('public.local_evento_id_seq'::regclass);


--
-- Name: notificacao id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.notificacao ALTER COLUMN id SET DEFAULT nextval('public.notificacao_id_seq'::regclass);


--
-- Name: orcamento id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.orcamento ALTER COLUMN id SET DEFAULT nextval('public.orcamento_id_seq'::regclass);


--
-- Name: parametro_custo id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.parametro_custo ALTER COLUMN id SET DEFAULT nextval('public.parametro_custo_id_seq'::regclass);


--
-- Name: repertorio_banda id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.repertorio_banda ALTER COLUMN id SET DEFAULT nextval('public.repertorio_banda_id_seq'::regclass);


--
-- Name: reporte_de_erro id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.reporte_de_erro ALTER COLUMN id SET DEFAULT nextval('public.reporte_de_erro_id_seq'::regclass);


--
-- Name: resposta_notificacao id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resposta_notificacao ALTER COLUMN id SET DEFAULT nextval('public.resposta_notificacao_id_seq'::regclass);


--
-- Name: servico_estudio id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.servico_estudio ALTER COLUMN id SET DEFAULT nextval('public.servico_estudio_id_seq'::regclass);


--
-- Name: show id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.show ALTER COLUMN id SET DEFAULT nextval('public.show_id_seq'::regclass);


--
-- Name: usuario id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.usuario ALTER COLUMN id SET DEFAULT nextval('public.usuario_id_seq'::regclass);


--
-- Data for Name: avaliacao_estudio; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.avaliacao_estudio (id, atendimento, data_avaliacao, estrutura, experiencia_geral, organizacao, qualidade_som, id_estudio, id_usuario) FROM stdin;
\.


--
-- Data for Name: avaliacao_local_evento; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.avaliacao_local_evento (id, atendimento, data_avaliacao, estrutura, experiencia_geral, organizacao, qualidade_som, id_local_evento, id_usuario) FROM stdin;
\.


--
-- Data for Name: banda; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.banda (id, categoria, data_inclusao, descricao, bairro, cep, cidade, estado, numero, pais, rua, nome, exigir_aprovacao_compromissos, listar_observacao_repertorio, permite_entrada_por_convite, url_logo) FROM stdin;
\.


--
-- Data for Name: condicao_orcamento; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.condicao_orcamento (id, condicao, id_banda, id_orcamento) FROM stdin;
\.


--
-- Data for Name: ensaio; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.ensaio (id, data, data_inclusao, duracao, bairro, cep, cidade, estado, numero, pais, rua, horario_inicio, local, observacoes, status, tipo_evento, valor, id_banda, id_estudio) FROM stdin;
\.


--
-- Data for Name: equipamento_estudio; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.equipamento_estudio (id, ativo, marca, modelo, observacao, quantidade, id_estudio) FROM stdin;
\.


--
-- Data for Name: equipamento_local_evento; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.equipamento_local_evento (id, ativo, marca, modelo, observacao, quantidade, id_local_evento) FROM stdin;
\.


--
-- Data for Name: estado_notificacao; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.estado_notificacao (id, mensagem_adicional, status_notificacao, id_usuario, id_notificacao) FROM stdin;
\.


--
-- Data for Name: estudio; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.estudio (id, data_inclusao, descricao, bairro, cep, cidade, estado, numero, pais, rua, horario_final_funcionamento, horario_inicio_funcionamento, nome, url_foto_perfil, id_usuario) FROM stdin;
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
\.


--
-- Data for Name: item_orcamento; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.item_orcamento (id, nome_parametro, quantidade, subtotal, unidade, valor_customizado, valor_unitario, id_orcamento) FROM stdin;
\.


--
-- Data for Name: local_evento; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.local_evento (id, data_inclusao, bio, bairro, cep, cidade, estado, numero, pais, rua, horario_final_funcionamento, horario_inicio_funcionamento, nome, url_foto_perfil, id_usuario) FROM stdin;
\.


--
-- Data for Name: musico_banda; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.musico_banda (instrumentos, id_banda, id_usuario) FROM stdin;
\.


--
-- Data for Name: musico_evento; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.musico_evento (id_evento, id_usuario, tipo_evento, cache, instrumentos, situacao) FROM stdin;
\.


--
-- Data for Name: notificacao; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.notificacao (tipo, id, data_criacao, destinatario_id, destinatario_tipo, lida, mensagem, remetente_id, remetente_tipo, titulo, url_imagem, id_ensaio, tipo_evento) FROM stdin;
\.


--
-- Data for Name: orcamento; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.orcamento (id, data_geracao, valor_total, id_banda, id_evento) FROM stdin;
\.


--
-- Data for Name: parametro_custo; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.parametro_custo (id, descricao, nome, tipo_calculo, unidade, valor_unitario, id_banda) FROM stdin;
\.


--
-- Data for Name: permissao_musico_banda; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.permissao_musico_banda (id_banda, id_usuario, permissoes) FROM stdin;
\.


--
-- Data for Name: relacionamento_seguidor; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.relacionamento_seguidor (id_seguido, id_seguidor, data_aceitacao, data_solicitacao, status) FROM stdin;
\.


--
-- Data for Name: repertorio_banda; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.repertorio_banda (id, artista, descricao, duracao, observacao, titulo, tonalidade, id_banda) FROM stdin;
\.


--
-- Data for Name: repertorio_evento; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.repertorio_evento (id_banda, id_evento, indice, tipo_evento, bloco, artista, descricao, duracao, observacao, titulo, tonalidade) FROM stdin;
\.


--
-- Data for Name: reporte_de_erro; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.reporte_de_erro (id, mensagem, id_usuario) FROM stdin;
\.


--
-- Data for Name: resposta_notificacao; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.resposta_notificacao (id, acao, data_resposta, mensagem, notificacao_id) FROM stdin;
\.


--
-- Data for Name: servico_estudio; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.servico_estudio (id, descricao, nome, valor, id_estudio) FROM stdin;
\.


--
-- Data for Name: show; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.show (id, data, data_inclusao, duracao, bairro, cep, cidade, estado, numero, pais, rua, horario_inicio, local, observacoes, status, tipo_evento, horario_passagem_som, is_portaria, porcentagem_portaria, valor_contrato, id_banda, id_local_evento) FROM stdin;
\.


--
-- Data for Name: spring_session; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.spring_session (primary_id, session_id, creation_time, last_access_time, max_inactive_interval, expiry_time, principal_name) FROM stdin;
\.


--
-- Data for Name: spring_session_attributes; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.spring_session_attributes (session_primary_id, attribute_name, attribute_bytes) FROM stdin;
\.


--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.usuario (id, ativo, bloqueado, celular, cidade, data_criacao, data_nascimento, descricao, email, nome, permissao, senha, url_foto_perfil) FROM stdin;
1	t	f	\N	\N	2025-09-04	1995-11-27	\N	caio@gmail.com	Caio	USUARIO	$2a$10$bFAgiuQuQMwO9mcPV0dIseOxUOsj.WXGCwt5eCEl2yFZ7slo6rhKa	default
\.


--
-- Name: avaliacao_estudio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.avaliacao_estudio_id_seq', 1, false);


--
-- Name: avaliacao_local_evento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.avaliacao_local_evento_id_seq', 1, false);


--
-- Name: banda_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.banda_id_seq', 1, false);


--
-- Name: condicao_orcamento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.condicao_orcamento_id_seq', 1, false);


--
-- Name: ensaio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.ensaio_id_seq', 1, false);


--
-- Name: equipamento_estudio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.equipamento_estudio_id_seq', 1, false);


--
-- Name: equipamento_local_evento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.equipamento_local_evento_id_seq', 1, false);


--
-- Name: estado_notificacao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.estado_notificacao_id_seq', 1, false);


--
-- Name: estudio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.estudio_id_seq', 1, false);


--
-- Name: item_orcamento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.item_orcamento_id_seq', 1, false);


--
-- Name: local_evento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.local_evento_id_seq', 1, false);


--
-- Name: notificacao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.notificacao_id_seq', 1, false);


--
-- Name: orcamento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.orcamento_id_seq', 1, false);


--
-- Name: parametro_custo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.parametro_custo_id_seq', 1, false);


--
-- Name: repertorio_banda_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.repertorio_banda_id_seq', 1, false);


--
-- Name: reporte_de_erro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.reporte_de_erro_id_seq', 1, false);


--
-- Name: resposta_notificacao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.resposta_notificacao_id_seq', 1, false);


--
-- Name: servico_estudio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.servico_estudio_id_seq', 1, false);


--
-- Name: show_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.show_id_seq', 1, false);


--
-- Name: usuario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.usuario_id_seq', 1, true);


--
-- Name: avaliacao_estudio avaliacao_estudio_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.avaliacao_estudio
    ADD CONSTRAINT avaliacao_estudio_pkey PRIMARY KEY (id);


--
-- Name: avaliacao_local_evento avaliacao_local_evento_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.avaliacao_local_evento
    ADD CONSTRAINT avaliacao_local_evento_pkey PRIMARY KEY (id);


--
-- Name: banda banda_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.banda
    ADD CONSTRAINT banda_pkey PRIMARY KEY (id);


--
-- Name: condicao_orcamento condicao_orcamento_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.condicao_orcamento
    ADD CONSTRAINT condicao_orcamento_pkey PRIMARY KEY (id);


--
-- Name: ensaio ensaio_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.ensaio
    ADD CONSTRAINT ensaio_pkey PRIMARY KEY (id);


--
-- Name: equipamento_estudio equipamento_estudio_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.equipamento_estudio
    ADD CONSTRAINT equipamento_estudio_pkey PRIMARY KEY (id);


--
-- Name: equipamento_local_evento equipamento_local_evento_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.equipamento_local_evento
    ADD CONSTRAINT equipamento_local_evento_pkey PRIMARY KEY (id);


--
-- Name: estado_notificacao estado_notificacao_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.estado_notificacao
    ADD CONSTRAINT estado_notificacao_pkey PRIMARY KEY (id);


--
-- Name: estudio estudio_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.estudio
    ADD CONSTRAINT estudio_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: item_orcamento item_orcamento_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.item_orcamento
    ADD CONSTRAINT item_orcamento_pkey PRIMARY KEY (id);


--
-- Name: local_evento local_evento_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.local_evento
    ADD CONSTRAINT local_evento_pkey PRIMARY KEY (id);


--
-- Name: musico_banda musico_banda_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.musico_banda
    ADD CONSTRAINT musico_banda_pkey PRIMARY KEY (id_banda, id_usuario);


--
-- Name: musico_evento musico_evento_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.musico_evento
    ADD CONSTRAINT musico_evento_pkey PRIMARY KEY (id_evento, id_usuario, tipo_evento);


--
-- Name: notificacao notificacao_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.notificacao
    ADD CONSTRAINT notificacao_pkey PRIMARY KEY (id);


--
-- Name: orcamento orcamento_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.orcamento
    ADD CONSTRAINT orcamento_pkey PRIMARY KEY (id);


--
-- Name: parametro_custo parametro_custo_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.parametro_custo
    ADD CONSTRAINT parametro_custo_pkey PRIMARY KEY (id);


--
-- Name: relacionamento_seguidor relacionamento_seguidor_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.relacionamento_seguidor
    ADD CONSTRAINT relacionamento_seguidor_pkey PRIMARY KEY (id_seguido, id_seguidor);


--
-- Name: repertorio_banda repertorio_banda_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.repertorio_banda
    ADD CONSTRAINT repertorio_banda_pkey PRIMARY KEY (id);


--
-- Name: repertorio_evento repertorio_evento_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.repertorio_evento
    ADD CONSTRAINT repertorio_evento_pkey PRIMARY KEY (id_banda, id_evento, indice, tipo_evento);


--
-- Name: reporte_de_erro reporte_de_erro_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.reporte_de_erro
    ADD CONSTRAINT reporte_de_erro_pkey PRIMARY KEY (id);


--
-- Name: resposta_notificacao resposta_notificacao_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resposta_notificacao
    ADD CONSTRAINT resposta_notificacao_pkey PRIMARY KEY (id);


--
-- Name: servico_estudio servico_estudio_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.servico_estudio
    ADD CONSTRAINT servico_estudio_pkey PRIMARY KEY (id);


--
-- Name: show show_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.show
    ADD CONSTRAINT show_pkey PRIMARY KEY (id);


--
-- Name: spring_session_attributes spring_session_attributes_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.spring_session_attributes
    ADD CONSTRAINT spring_session_attributes_pk PRIMARY KEY (session_primary_id, attribute_name);


--
-- Name: spring_session spring_session_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.spring_session
    ADD CONSTRAINT spring_session_pk PRIMARY KEY (primary_id);


--
-- Name: estado_notificacao uk_ptyt5a5e4g3tgl1ks88jnnnyx; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.estado_notificacao
    ADD CONSTRAINT uk_ptyt5a5e4g3tgl1ks88jnnnyx UNIQUE (id_notificacao);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: spring_session_ix1; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX spring_session_ix1 ON public.spring_session USING btree (session_id);


--
-- Name: spring_session_ix2; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX spring_session_ix2 ON public.spring_session USING btree (expiry_time);


--
-- Name: spring_session_ix3; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX spring_session_ix3 ON public.spring_session USING btree (principal_name);


--
-- Name: avaliacao_estudio fk1p3jdtwtppoevacg1jsx474d1; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.avaliacao_estudio
    ADD CONSTRAINT fk1p3jdtwtppoevacg1jsx474d1 FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: condicao_orcamento fk1xntry1l52j4y05k6fbm7vqju; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.condicao_orcamento
    ADD CONSTRAINT fk1xntry1l52j4y05k6fbm7vqju FOREIGN KEY (id_banda) REFERENCES public.banda(id);


--
-- Name: equipamento_estudio fk2vtn1813h5btoenad25rm9exi; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.equipamento_estudio
    ADD CONSTRAINT fk2vtn1813h5btoenad25rm9exi FOREIGN KEY (id_estudio) REFERENCES public.estudio(id);


--
-- Name: ensaio fk3dpih5xooqv5fjtfsnprl3c8k; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.ensaio
    ADD CONSTRAINT fk3dpih5xooqv5fjtfsnprl3c8k FOREIGN KEY (id_estudio) REFERENCES public.estudio(id);


--
-- Name: estado_notificacao fk5fx1bmxfga5197r98hbv81k2c; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.estado_notificacao
    ADD CONSTRAINT fk5fx1bmxfga5197r98hbv81k2c FOREIGN KEY (id_notificacao) REFERENCES public.notificacao(id);


--
-- Name: local_evento fk6kdyg3j9drox47rruatmpqlhp; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.local_evento
    ADD CONSTRAINT fk6kdyg3j9drox47rruatmpqlhp FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: orcamento fk78pl073fke2nnckjxb4i9714; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.orcamento
    ADD CONSTRAINT fk78pl073fke2nnckjxb4i9714 FOREIGN KEY (id_evento) REFERENCES public.show(id);


--
-- Name: estado_notificacao fk9g8o6dycmrnfcl4q7v6s0b1hd; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.estado_notificacao
    ADD CONSTRAINT fk9g8o6dycmrnfcl4q7v6s0b1hd FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: equipamento_local_evento fk9gow5x6e70bipmbu8jqtgxwpy; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.equipamento_local_evento
    ADD CONSTRAINT fk9gow5x6e70bipmbu8jqtgxwpy FOREIGN KEY (id_local_evento) REFERENCES public.local_evento(id);


--
-- Name: estudio fk9ivma2s038155357ywfwnxdu0; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.estudio
    ADD CONSTRAINT fk9ivma2s038155357ywfwnxdu0 FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: orcamento fk9jg7bjut9v3c4748ilr8mwmp1; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.orcamento
    ADD CONSTRAINT fk9jg7bjut9v3c4748ilr8mwmp1 FOREIGN KEY (id_banda) REFERENCES public.banda(id);


--
-- Name: musico_banda fkaxl44e1htgl5xl0823f9dnip5; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.musico_banda
    ADD CONSTRAINT fkaxl44e1htgl5xl0823f9dnip5 FOREIGN KEY (id_banda) REFERENCES public.banda(id);


--
-- Name: avaliacao_estudio fke309edpkncg7nb5ct6uytxmr9; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.avaliacao_estudio
    ADD CONSTRAINT fke309edpkncg7nb5ct6uytxmr9 FOREIGN KEY (id_estudio) REFERENCES public.estudio(id);


--
-- Name: show fkgdk5qtbnyqr963qw88v9hxlc1; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.show
    ADD CONSTRAINT fkgdk5qtbnyqr963qw88v9hxlc1 FOREIGN KEY (id_banda) REFERENCES public.banda(id);


--
-- Name: reporte_de_erro fkgyln7kyfxqcoce8cvtyawn233; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.reporte_de_erro
    ADD CONSTRAINT fkgyln7kyfxqcoce8cvtyawn233 FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: condicao_orcamento fkh2cqdakh665qh5yehrqithtcw; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.condicao_orcamento
    ADD CONSTRAINT fkh2cqdakh665qh5yehrqithtcw FOREIGN KEY (id_orcamento) REFERENCES public.orcamento(id);


--
-- Name: repertorio_banda fkhk08rkagen6chwjpobafu0uvk; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.repertorio_banda
    ADD CONSTRAINT fkhk08rkagen6chwjpobafu0uvk FOREIGN KEY (id_banda) REFERENCES public.banda(id);


--
-- Name: show fkhvghuxbm7dm9eswwtkb00rjvv; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.show
    ADD CONSTRAINT fkhvghuxbm7dm9eswwtkb00rjvv FOREIGN KEY (id_local_evento) REFERENCES public.local_evento(id);


--
-- Name: servico_estudio fkl01dad4yth5ykb0mior1exdmd; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.servico_estudio
    ADD CONSTRAINT fkl01dad4yth5ykb0mior1exdmd FOREIGN KEY (id_estudio) REFERENCES public.estudio(id);


--
-- Name: musico_banda fkmtqii6unxlhcy03uin6hc9cho; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.musico_banda
    ADD CONSTRAINT fkmtqii6unxlhcy03uin6hc9cho FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: musico_evento fkn7uq35x4ao3k6isrj4pa53o8o; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.musico_evento
    ADD CONSTRAINT fkn7uq35x4ao3k6isrj4pa53o8o FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: ensaio fko4drhghq5cc8n4b1jl8itpowl; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.ensaio
    ADD CONSTRAINT fko4drhghq5cc8n4b1jl8itpowl FOREIGN KEY (id_banda) REFERENCES public.banda(id);


--
-- Name: permissao_musico_banda fkovvotd7jj745ts422xtfusqa8; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.permissao_musico_banda
    ADD CONSTRAINT fkovvotd7jj745ts422xtfusqa8 FOREIGN KEY (id_banda, id_usuario) REFERENCES public.musico_banda(id_banda, id_usuario);


--
-- Name: parametro_custo fkprea1p45s9w5nvb0oudq3y2s; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.parametro_custo
    ADD CONSTRAINT fkprea1p45s9w5nvb0oudq3y2s FOREIGN KEY (id_banda) REFERENCES public.banda(id);


--
-- Name: item_orcamento fks395a721oddo74ry18sc7glx3; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.item_orcamento
    ADD CONSTRAINT fks395a721oddo74ry18sc7glx3 FOREIGN KEY (id_orcamento) REFERENCES public.orcamento(id);


--
-- Name: avaliacao_local_evento fktmi7xyojeuyr7affid6ov4wqv; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.avaliacao_local_evento
    ADD CONSTRAINT fktmi7xyojeuyr7affid6ov4wqv FOREIGN KEY (id_usuario) REFERENCES public.usuario(id);


--
-- Name: avaliacao_local_evento fktn435e2yxtwysqhnc3in95399; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.avaliacao_local_evento
    ADD CONSTRAINT fktn435e2yxtwysqhnc3in95399 FOREIGN KEY (id_local_evento) REFERENCES public.local_evento(id);


--
-- Name: spring_session_attributes spring_session_attributes_fk; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.spring_session_attributes
    ADD CONSTRAINT spring_session_attributes_fk FOREIGN KEY (session_primary_id) REFERENCES public.spring_session(primary_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict IcCWT07hdaGbNJuzDDHzLQc15tOveRe4SW9uiXR39Zkymg47YbAZIsFsgGBUN6s

